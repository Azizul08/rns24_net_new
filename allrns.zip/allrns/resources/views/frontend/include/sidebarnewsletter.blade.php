<!-- Sidebar Widget -->
<div class="single-sidebar-widget p-30">
    <!-- Section Title -->
    <div class="section-heading">
        <h5>Newsletter</h5>
    </div>

    <div class="newsletter-form">
        <p>Subscribe our newsletter gor get notification about new updates, information discount, etc.</p>
        <form action="#" method="get">
            <input type="search" name="widget-search" placeholder="Enter your email">
            <button type="submit" class="btn mag-btn w-100">Subscribe</button>
        </form>
    </div>

</div>