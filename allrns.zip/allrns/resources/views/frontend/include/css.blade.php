<!--- Font Awesome CSS 5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css"> 

<link rel="stylesheet" href="{{ asset('frontend/css/fencybox.min.css') }}">

<!-- Stylesheet -->
<link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/css/responsive.css') }}">