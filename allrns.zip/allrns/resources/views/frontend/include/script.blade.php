<!-- ##### All Javascript Script ##### -->
<!-- jQuery-2.2.4 js -->
<script src="{{ asset('frontend/js/jquery/jquery-2.2.4.min.js') }}"></script>
<!-- Popper js -->
<script src="{{ asset('frontend/js/bootstrap/popper.min.js') }}"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- Bootstrap js -->
<script src="{{ asset('frontend/js/bootstrap/bootstrap.min.js') }}"></script>

<script src="{{ asset('frontend/js/fencybox.min.js') }}"></script>
<script src="{{ asset('frontend/js/fency.js') }}"></script>
<!-- All Plugins js -->
<script src="{{ asset('frontend/js/plugins/plugins.js') }}"></script>
<!-- Active js -->
<script src="{{ asset('frontend/js/active.js') }}"></script>