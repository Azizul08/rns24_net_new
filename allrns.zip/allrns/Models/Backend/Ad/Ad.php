<?php

namespace App\Models\Backend\Ad;

use Illuminate\Database\Eloquent\Model;

class Ad extends Model
{
    //
}
