<?php

namespace App\Models\Backend\About;

use Illuminate\Database\Eloquent\Model;

class AboutInfo extends Model
{
    //
}
