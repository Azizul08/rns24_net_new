<?php

namespace App\Models\Backend\Title;

use Illuminate\Database\Eloquent\Model;

class Title extends Model
{
    //
}
